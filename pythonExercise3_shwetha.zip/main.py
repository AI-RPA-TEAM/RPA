#Q01
def prodsum(a,b):
     c=a*b
     if(c>1000):
       print(a+b)
     else:
       print(c)
       
n1=int(input("Enter first number"))
n2=int(input("Enter second number "))
prodsum(n1,n2)

#q02
x,y=0,1
print("Printing current and previous number sum in a given range(10)")
print("Current Number 0 Previous Number 0 Sum 0")
while y<10:
      print("Current Number",x,"previous Number",y ,"Sum",x+y)
      x,y = y,x+y
    

#q03
str=input("enter a string")
for i in range(len(str)):
  if i%2==0 :
    
    print("index[", i ,"]" ,str[i])
#q04
str=input("enter a string")

val=int(input("enter number of characters to remove"))

if(val<len(str)):
 
   print(str[val:])

#q05
n = int(input("Enter the size of list : "))
numList = list(int(num) for num in input("Enter the list numbers separated by space: ").strip().split())[:n]
#print("New List: ", numList)
print(numList[n-1]);
if numList[0]==numList[n-1] :
 print("true")
else :
 print("false")

#q06
n = int(input("Enter the size of list : "))
numList = list(int(num) for num in input("Enter the list numbers separated by space: ").strip().split())[:n]
#print("New List: ", numList)
for i in numList:
   if i%5 ==0 :
     print(i)

#q07
str = input("Enter the string : ")
search= input("Enter the search word :")
ct=str.count(search)
print(search,"appeared",ct,"times")

#q08
num = int(input("Enter the number : "))
for i in range(num):
    print(str(i) * i)

#q09
num = int(input("Enter the number : "))
res = str(num) == str(num)[::-1]
print("The original and reverse number is the same :",res)

#q10
n1 = int(input("Enter the size of list1 : "))
List1 = list(int(num) for num in input("Enter the list numbers separated by space: ").strip().split())[:n1]
n2= int(input("Enter the size of list2 : "))
List2 = list(int(num) for num in input("Enter the list numbers separated by space: ").strip().split())[:n2]
List3=[]
for i in List1:
  if i%2!=0 :
    List3.append(i)
for i in List2:
  if i%2==0 :
    List3.append(i)
print(List3)

	

  
    