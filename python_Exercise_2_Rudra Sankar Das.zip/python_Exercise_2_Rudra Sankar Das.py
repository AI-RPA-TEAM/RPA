#1  
import datetime

name= input("Enter name: ")
dob= input("Enter DOB in dd-mm-yyyy format: ")
dd,mm,yyyy=map(int, dob.split('-'))
hunderedyear=yyyy+100
hundday=datetime.datetime(hunderedyear, mm, dd,00,00,00,00)
print("Hello %s, You will turn 100 years old in the year %s. Day of your 100th Birthday is on %s."%(name,hunderedyear,hundday.strftime("%A")))


#3
a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
b = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
xx=set(a)
yy=set(b)
zz=list(xx.intersection(yy))
print(zz) 

#2
num = int(input(""))
rngnum=(num//2)+1
listRange = list(range(1,rngnum+1))
list1 = []
for number in listRange:
    if num % number == 0:
        list1.append(number)
list1.append(num)
print(list1) 

#5
class Math:
    pi=22/7
    def __init__(a,radius):
        a.radius=float(radius)

    def Area(a):
        a.area=a.pi*a.radius*a.radius
        return a.area
    
    def Circumference(a):
        a.circumference=2.0*a.pi*a.radius
        return a.circumference

#4
input = input()
ans = isPalindrome(input)
print(ans)