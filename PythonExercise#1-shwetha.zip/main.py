#01
print("Twinkle, twinkle, little star, \n\tHow I wonder what you are! \n\t\tUp above the world so high, \n\t\tLike a diamond in the sky. \nTwinkle, twinkle, little star, \n\tHow I wonder what you are!")

#12
print("""
a string that you "don't" have to escape
This
is a  ....... multi-line
heredoc string --------> example
""")

import sys
#system version
print(sys.version)

#to display datetime
import datetime
print(datetime.datetime.now())

#to print fname and last name
fname=input("Enter first Name")
lname=input("Enter last Name")
print(lname+" "+fname)

#to print list and tuples
num=input("enter the numbers")
listval=num.split(",")
tupleval=tuple(listval)
print("List Format :" ,listval)
print("Tuple Format :" ,tupleval)

#to print file extension
file=input("enter the filename")
sfile=file.split(".")
print("File Format :" + repr(sfile[-1]))

#to print first and last colour
color=["Red","Green","White","Black"]
print(color[0])
print(color[3])

#to print in date format
exam_st_date = (11,12,2014)
print( "The examination will start from : %i / %i / %i"%exam_st_date)

#display month and year in calendar
import calendar
year = int(input("Input year : "))
month = int(input("Input month : "))
print(calendar.month(year, month))

#to input n+nn+nnn
n= int(input("Input an integer : "))
n1 = int( "%s" % n )
n2 = int( "%s%s" % (n,n) )
n3 = int( "%s%s%s" % (n,n,n) )
print (n1+n2+n3)
#to print description of built in functions
print(abs.__doc__)

#to print the diffference between two dates
from datetime import date
f_date = date(2014, 7, 2)
l_date = date(2014, 7, 11)
diff = l_date - f_date
print(diff.days)

print("Twinkle, twinkle, little star, \n\tHow I wonder what you are! \n\t\tUp above the world so high, \n\t\tLike a diamond in the sky. \nTwinkle, twinkle, little star, \n\tHow I wonder what you are!")


