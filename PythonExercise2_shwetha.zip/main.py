#Q05
import Math as m
r=int(input("Enter radius of circle: "))
obj=m.circle(r)
print("Area of circle:",round(obj.area(),2))
print("Perimeter of circle:",round(obj.perimeter(),2))

#Q01
import datetime
import calendar

name=input("Give me your Name")
DB =input("Give me your DOB")
D=datetime.datetime.strptime(DB,'%d %m %Y')
ND=D.replace(year = D.year+100)
print("Hello " +name+ ", You will turn 100 years old in the year" ,ND.year)
N=ND.weekday()
day_name= ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday','Sunday']
print("Day of your 100th Birthday is ",day_name[N])

#to print divisors-Q02
N=(int)(input("Enter Number: "))
mylist=[]
for x in range(1,N+1):
    if(N%x==0):
        #print(x)
        mylist.append(x);
        
print(mylist)

#intersect elements-Q03
List1= [1, 2, 3, 4, 5,6,11] 
List2= [5, 6, 7, 8, 9,10] 
L1=set(List1)
L2=set(List2)
      
if len(L1.intersection(L2)) > 0: 
    print(L1.intersection(L2))   
else: 
    print("no common elements") 
    
#palindrome-Q04
st=input("Enter the string")
st=st.casefold()
rev=reversed(st)

if list(st)==list(rev) :
 print("Palindrome");
else:
 print("Not Palindrome")
