import datetime
import calendar
import math__

# program 1
def when_100_year(date,month,year,name):
    op=year+100
    day=datetime.date(op,month,date)
    output="Hello ",name,", you will turn 100 years old in the year ",str(op),".","Day of your 100th Birthday is ",day.strftime("%A")
    return(''.join(output))

# program 2
def divisor(n):
    return([i for i in range(1,n+1) if n%i == 0])

# program 3
def intersection(l1,l2):
    return([i for i in l1 if i in l2])

# program 4
def palindrome(string):
    string=string.lower()
    return(["The word is a palindrome" if string == string[::-1] else "The word is not a palindrome"])

# program 5
def circle(radius):
    obj=math__.Math(radius)
    output="Area: ",str(obj.area())," Circumference: ",str(obj.circumference())
    return(''.join(output))
