#!/usr/bin/env python
# coding: utf-8
1. Write a Python program to print the following string in a specific format (see the output).  
Sample String : "Twinkle, twinkle, little star, How I wonder what you are! Up above the world so high, Like a diamond in the sky. Twinkle, twinkle, little star, How I wonder what you are" 
Expected Output :
Twinkle, twinkle, little star,
            How I wonder what you are! 
                    Up above the world so high,
                    Like a diamond in the sky. 
Twinkle, twinkle, little star, 
            How I wonder what you are
# In[10]:


input="Twinkle, twinkle, little star,\n\t\t How I wonder what you are!\n\t\t\t Up above the world so high,\n\t\t\t Like a diamond in the sky. \nTwinkle, twinkle, little star, \n\tHow I wonder what you are" 
print(input)

2. Write a Python program to get the Python version you are using.  
# In[11]:


import sys
print (sys.version)

3. Write a Python program to display the current date and time.
Sample Output :
Current date and time :
2020-22-02 14:34:14
# In[28]:


import datetime

now = datetime.datetime.now()

print("Current date and time: ")
print(now.strftime('%Y-%m-%d %H:%M:%S'))

4. Write a Python program which accepts the user's first and last name and print them in reverse order with a space between them. 
# In[2]:


fname = input("Input your First Name : ")
lname = input("Input your Last Name : ")
print (lname + " " + fname)

5. Write a Python program which accepts a sequence of comma-separated numbers from user and generate a list and a tuple with those numbers.  
Sample data : 3, 5, 7, 23
Output :
List : ['3', ' 5', ' 7', ' 23']
Tuple : ('3', ' 5', ' 7', ' 23')
# In[4]:


input1 = input("Input a sequence of comma-separated numbers: ")
list1=list(input1.split(","))
print(list1)
list2=tuple(input1.split(","))
print(list2)

6. Write a Python program to accept a filename from the user and print the extension of that.  
Sample filename : abc.java
Output : java
# In[6]:


filename = input("Input the Filename: ")
extns = filename.split(".")
print(extns[-1])

7. Write a Python program to display the first and last colors from the following list.  
color_list = ["Red","Green","White" ,"Black"]
# In[7]:


color_list = ["Red","Green","White" ,"Black"]
print(color_list[0])
print(color_list[-1])

8. Write a Python program to display the examination schedule. (extract the date from exam_st_date).  
exam_st_date = (11, 12, 2014)
Sample Output : The examination will start from : 11 / 12 / 2014
# In[8]:


exam_st_date = (11,12,2014)

print( "The examination will start from : %i / %i / %i"%exam_st_date)

9. Write a Python program that accepts an integer (n) and computes the value of n+nn+nnn.  
Sample value of n is 5
Expected Result : 615
# In[9]:


a = int(input("Input an integer : "))
n1 = int( "%s" % a )
n2 = int( "%s%s" % (a,a) )
n3 = int( "%s%s%s" % (a,a,a) )
print (n1+n2+n3)

10. Write a Python program to print the documents (syntax, description etc.) of Python built-in function(s).
Sample function : abs()
Expected Result :
abs(number) -> number
Return the absolute value of the argument.
# In[10]:


print(abs.__doc__)

11. Write a Python program to print the calendar of a given month and year.
Note : Use 'calendar' module.
# In[12]:


import calendar as ca
y = int(input("Input the year : "))
m = int(input("Input the month : "))
print(ca.month(y, m))

12. Write a Python program to print the following here document. 
Sample string :
a string that you "don't" have to escape
This
is a ....... multi-line
heredoc string --------> example
# In[13]:


print("""
a string that you "don't" have to escape
This
is a  ....... multi-line
heredoc string --------> example
""")

13. Write a Python program to calculate number of days between two dates.
Sample dates : (2014, 7, 2), (2014, 7, 11)
Expected output : 9 days
# In[14]:


from datetime import date
fdate = date(2014, 7, 2)
ldate = date(2014, 7, 11)
delta = ldate - fdate
print(delta.days)

