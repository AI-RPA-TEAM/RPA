import calendar
mon=int(input())
year=int(input())
print(calendar.month(year,mon))
