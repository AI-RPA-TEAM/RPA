inp=map(int,input().strip().split())
li=list(inp)
print(li)
print(tuple(li))
