date=list(input().strip().split())
print("/".join(date))
