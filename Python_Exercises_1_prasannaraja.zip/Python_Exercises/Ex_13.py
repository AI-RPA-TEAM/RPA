from datetime import date
date1=list(map(int,input("Enter date 1").strip().split()))
date2=list(map(int,input("Enter date 2").strip().split()))
updated_date1=date(date1[2],date1[1],date1[0])
updated_date2=date(date2[2],date2[1],date2[0])
print((updated_date2-updated_date1).days," days")

