file=input()
print(file[(file.index(".")+1):])
