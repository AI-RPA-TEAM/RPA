colors=list(input().strip().split())
print(colors[0],colors[-1])
