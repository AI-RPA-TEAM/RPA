print(' '.join(input('Enter your name: ').split(' ')[::-1]))

